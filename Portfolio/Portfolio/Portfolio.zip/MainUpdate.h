#pragma once

class MainUpdate
{
public:
	void Initialize();
	void Update();
	void Render();
	void Release();

	MainUpdate();
	~MainUpdate();
};

