#pragma once
#include "PlayerBridge.h"

class Player1 : public PlayerBridge
{
public:
	virtual void Initialize()override;
	virtual int Update(Transform& Info)override;
	virtual void Render()override;
	virtual void Release()override;

	Player1();
	virtual ~Player1();
};

