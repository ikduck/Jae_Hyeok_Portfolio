#include "Player1.h"
#include "InputManager.h"
#include "CursorManager.h"
#include "Bridge.h"
#include "NormalBullet.h"
#include "Object.h"
#include "ObjectManager.h"

Player1::Player1() { }
Player1::~Player1() { }

void Player1::Initialize()
{
	Buffer[0] = (char*)"������";
	Buffer[1] = (char*)"������";

	Speed = 1.0f;
	Color = 15;
}

int Player1::Update(Transform& TransInfo)
{
	DWORD dwKey = InputManager::GetInstance()->GetKey();

	if (dwKey & KEY_UP)
		TransInfo.Position.y -= 1;

	if (dwKey & KEY_DOWN)
		TransInfo.Position.y += 1;

	if (dwKey & KEY_LEFT)
		TransInfo.Position.x -= 1;

	if (dwKey & KEY_RIGHT)
		TransInfo.Position.x += 1;

	if (dwKey & KEY_SPACE)
	{
		Bridge* pBridge = new NormalBullet;
		ObjectManager::GetInstance()->AddObject("Bullet", pBridge);
		ObjectManager::GetInstance()->GetObjectList("Bullet")->back()->SetPosition(TransInfo.Position);
	}

	return 0;
}

void Player1::Render()
{
	for (int i = 0; i < 2; ++i)
	{
		CursorManager::GetInstance()->WriteBuffer(
			pObject->GetPosition().x,
			pObject->GetPosition().y + i,
			Buffer[i], Color);
	}
}

void Player1::Release()
{
}

