#include "Object.h"

Object::Object() { }
Object::Object(Transform _TransInfo) : TransInfo(_TransInfo) { }
Object::~Object() { }
