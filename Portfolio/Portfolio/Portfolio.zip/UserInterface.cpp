#include "UserInterface.h"

UserInterface::UserInterface()
{
}

UserInterface::UserInterface(Transform _TransInfo)
{
}

UserInterface::~UserInterface()
{
}
