#pragma once

enum SCENEID
{
	LOGO,
	MENU,
	STAGE,
	EXIT,
};
