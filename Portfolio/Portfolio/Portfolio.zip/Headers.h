#pragma once
#define  _CRT_SECURE_NO_WARNINGS

#include <Windows.h> 
#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <string> 
#include<math.h>

#include "Define.h"
#include "Enum.h"
#include "Constent.h"
#include "Struct.h"

using namespace std;
